import showNose1 from './showNose1'
import showNose2 from './showNose2'
import showNose3 from './showNose3'
import showSnow from './showSnow'
import pageHandle from './pageHandle'

export { showNose1, showNose2, showNose3, showSnow, pageHandle }
